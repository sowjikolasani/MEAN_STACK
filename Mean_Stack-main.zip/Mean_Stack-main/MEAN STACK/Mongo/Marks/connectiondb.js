module.exports = {
  // url: "mongodb+srv://YaswanthKrishna:Yaswanth84@cluster0.iqn1qsh.mongodb.net/?retryWrites=true&w=majority",
  // url: "mongodb://127.0.0.1:27017/student_db",
  url: "mongodb://127.0.0.1:27017/marks_db",
};
